# توصيله — تشغيل المشروع

## تشغيل محلي
1. محتاج Node.js 18+ وقاعدة PostgreSQL.
2. `cp .env.example .env` وعدّل القيم، وبعدين:
   ```
   npm install
   export $(grep -v '^#' .env | xargs)   # أو استخدم أي أداة تحمّل .env
   npm start
   ```
3. افتح http://localhost:3000 وادخل بحساب الأدمن (ADMIN_PHONE / ADMIN_PASSWORD).
   لو شغّال محلي من غير HTTPS خلّي NODE_ENV فاضي.

## نشر على Render (أبسط طريقة)
1. ارفع مجلد المشروع على GitHub.
2. في Render: New → PostgreSQL، وانسخ الـ Internal Database URL.
3. New → Web Service من الريبو. Build: `npm install` — Start: `npm start`.
4. Environment Variables:
   - `DATABASE_URL` = الرابط اللي نسخته
   - `JWT_SECRET` = نص عشوائي 32 حرف أو أكتر
   - `ADMIN_PHONE` و `ADMIN_PASSWORD` = حساب الأدمن
   - `NODE_ENV` = production (ولو الرابط داخلي وطلع خطأ SSL ضيف `PGSSL=false`)
5. اربط دومينك من Settings → Custom Domains (الـ HTTPS تلقائي).

## بعد التشغيل
- ادخل كأدمن ← عدّل المناطق والأسعار ← ضيف الدليفري (اسم + موبايل + كلمة سر) وسلّمهم بياناتهم.
- العملاء بيسجّلوا حسابهم بنفسهم من الصفحة الرئيسية.
- الطلبات بتتحدث لحظياً (SSE). لو الدليفري ما ردش خلال دقيقة الطلب بيروح للي بعده.

## لسه ناقص قبل الإطلاق الكبير
- تفعيل الحساب بكود SMS (OTP) ونسيان كلمة السر.
- إشعارات Push حقيقية والتطبيق مغلق (PWA/Firebase).
- نسخ احتياطي تلقائي لقاعدة البيانات، ومراقبة الأخطاء.
