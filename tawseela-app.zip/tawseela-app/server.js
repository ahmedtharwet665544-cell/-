const express = require('express'), helmet = require('helmet'), rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken'), { Pool } = require('pg'), path = require('path');
const { PORT = 3000, JWT_SECRET: SECRET, DATABASE_URL, NODE_ENV, PGSSL, ADMIN_PHONE, ADMIN_PASSWORD } = process.env;
if (!SECRET || SECRET.length < 16) { console.error('JWT_SECRET (16+ chars) is required'); process.exit(1); }

const pool = new Pool({ connectionString: DATABASE_URL, ssl: PGSSL === 'false' ? false : NODE_ENV === 'production' ? { rejectUnauthorized: false } : false });
const q = (t, p) => pool.query(t, p).then(r => r.rows);
const PH = /^01[0125]\d{8}$/;
const BUSY = "('assigned','accepted','delivering')", ACTIVE = "('waiting','assigned','accepted','delivering')";
const TODAY = "(date_trunc('day', now() AT TIME ZONE 'Africa/Cairo') AT TIME ZONE 'Africa/Cairo')";
const OSEL = `SELECT o.id,o.txt,o.zone_name,o.addr,o.price,o.status,o.created_at,o.driver_id,
  c.name cname,c.phone cphone,d.name dname,d.phone dphone
  FROM orders o JOIN users c ON c.id=o.customer_id LEFT JOIN users d ON d.id=o.driver_id`;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users(id SERIAL PRIMARY KEY,name TEXT NOT NULL,phone TEXT UNIQUE NOT NULL,pass TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN('customer','driver','admin')),online BOOLEAN NOT NULL DEFAULT false,
  active BOOLEAN NOT NULL DEFAULT true,created_at TIMESTAMPTZ NOT NULL DEFAULT now());
CREATE TABLE IF NOT EXISTS zones(id SERIAL PRIMARY KEY,name TEXT NOT NULL,price INT NOT NULL CHECK(price>=0));
CREATE TABLE IF NOT EXISTS orders(id SERIAL PRIMARY KEY,customer_id INT NOT NULL REFERENCES users(id),
  driver_id INT REFERENCES users(id),txt TEXT NOT NULL,zone_name TEXT NOT NULL,addr TEXT NOT NULL,price INT NOT NULL,
  status TEXT NOT NULL DEFAULT 'waiting',rejected INT[] NOT NULL DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),assigned_at TIMESTAMPTZ,done_at TIMESTAMPTZ);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status);
CREATE INDEX IF NOT EXISTS orders_driver_idx ON orders(driver_id);
CREATE INDEX IF NOT EXISTS orders_customer_idx ON orders(customer_id);`;

/* ---------- live updates (SSE) ---------- */
const clients = new Set();
const broadcast = () => { for (const r of clients) r.write('data: refresh\n\n'); };
setInterval(() => { for (const r of clients) r.write(': ping\n\n'); }, 25000);

/* ---------- dispatch: give waiting orders to free drivers ---------- */
async function dispatch() {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query('SELECT pg_advisory_xact_lock(42)');
    const { rows: waiting } = await c.query("SELECT id,rejected FROM orders WHERE status='waiting' ORDER BY id");
    for (const o of waiting) {
      const { rows } = await c.query(
        `SELECT u.id FROM users u WHERE u.role='driver' AND u.online AND u.active AND NOT (u.id = ANY($1::int[]))
         AND NOT EXISTS(SELECT 1 FROM orders b WHERE b.driver_id=u.id AND b.status IN ${BUSY})
         ORDER BY (SELECT count(*) FROM orders d WHERE d.driver_id=u.id AND d.status='done' AND d.done_at>=${TODAY}), u.id LIMIT 1`,
        [o.rejected]);
      if (rows[0]) await c.query("UPDATE orders SET driver_id=$1,status='assigned',assigned_at=now() WHERE id=$2", [rows[0].id, o.id]);
    }
    await c.query('COMMIT');
  } catch (e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
  broadcast();
}
const RELEASE = "UPDATE orders SET rejected=array_append(rejected,driver_id),driver_id=NULL,status='waiting' WHERE driver_id=$1 AND status='assigned'";

// every 15s: driver silent for 60s -> next driver; clear rejections after 3 min so nobody is skipped forever
setInterval(async () => {
  try {
    await q("UPDATE orders SET rejected=array_append(rejected,driver_id),driver_id=NULL,status='waiting' WHERE status='assigned' AND assigned_at<now()-interval '60 seconds'");
    await q("UPDATE orders SET rejected='{}' WHERE status='waiting' AND cardinality(rejected)>0 AND created_at<now()-interval '3 minutes'");
    await dispatch();
  } catch (e) { console.error('tick', e.message); }
}, 15000);

/* ---------- app ---------- */
const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'"], scriptSrcAttr: ["'unsafe-inline'"],
  styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
  connectSrc: ["'self'"], imgSrc: ["'self'", 'data:'], upgradeInsecureRequests: null } } }));
app.use(express.json({ limit: '20kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const h = f => (req, res, next) => Promise.resolve(f(req, res)).catch(next);
const bad = (res, m, c = 400) => res.status(c).json({ error: m });
const lim = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false });
const sign = u => jwt.sign({ id: u.id }, SECRET, { expiresIn: '30d' });
const pub = u => ({ id: u.id, name: u.name, phone: u.phone, role: u.role });
const auth = role => async (req, res, next) => {
  let u;
  try {
    const p = jwt.verify((req.headers.authorization || '').slice(7), SECRET);
    [u] = await q('SELECT id,role,name,phone FROM users WHERE id=$1 AND active', [p.id]);
  } catch (e) { u = null; }
  if (!u) return bad(res, 'سجّل دخول من جديد', 401);
  if (role && u.role !== role) return bad(res, 'غير مسموح', 403);
  req.user = u; next();
};

/* auth */
app.post('/api/register', lim, h(async (req, res) => {
  const { name, phone, password } = req.body || {};
  if (!name || String(name).trim().length < 2) return bad(res, 'اكتب اسمك');
  if (!PH.test(phone)) return bad(res, 'رقم الموبايل غلط');
  if (!password || String(password).length < 6) return bad(res, 'كلمة السر 6 حروف على الأقل');
  const r = await q("INSERT INTO users(name,phone,pass,role) VALUES($1,$2,$3,'customer') ON CONFLICT(phone) DO NOTHING RETURNING id,name,phone,role",
    [String(name).trim().slice(0, 60), phone, await bcrypt.hash(String(password), 10)]);
  if (!r[0]) return bad(res, 'الرقم ده مسجّل قبل كده');
  res.json({ token: sign(r[0]), user: pub(r[0]) });
}));
app.post('/api/login', lim, h(async (req, res) => {
  const { phone, password } = req.body || {};
  const [u] = await q('SELECT * FROM users WHERE phone=$1', [String(phone || '')]);
  if (!u || !u.active || !(await bcrypt.compare(String(password || ''), u.pass))) return bad(res, 'الرقم أو كلمة السر غلط', 401);
  res.json({ token: sign(u), user: pub(u) });
}));
app.get('/api/zones', h(async (req, res) => res.json(await q('SELECT id,name,price FROM zones ORDER BY id'))));
app.get('/api/stream', (req, res) => {
  try { jwt.verify(String(req.query.token || ''), SECRET); } catch (e) { return res.sendStatus(401); }
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  res.flushHeaders(); res.write('retry: 3000\n\n');
  clients.add(res); req.on('close', () => clients.delete(res));
});

/* customer */
const custView = o => ({ id: o.id, txt: o.txt, zone: o.zone_name, addr: o.addr, price: o.price, status: o.status, at: o.created_at,
  driver: o.dname && ['accepted', 'delivering', 'done'].includes(o.status) ? { name: o.dname, phone: o.dphone } : null });
app.get('/api/orders/mine', auth('customer'), h(async (req, res) =>
  res.json((await q(`${OSEL} WHERE o.customer_id=$1 ORDER BY o.id DESC LIMIT 20`, [req.user.id])).map(custView))));
app.post('/api/orders', auth('customer'), h(async (req, res) => {
  const { txt, zone_id, addr } = req.body || {};
  if (!txt || !String(txt).trim()) return bad(res, 'اكتب طلبك');
  if (!addr || String(addr).trim().length < 5) return bad(res, 'اكتب العنوان بالتفصيل');
  const [z] = await q('SELECT * FROM zones WHERE id=$1', [+zone_id || 0]);
  if (!z) return bad(res, 'اختار المنطقة');
  const [n] = await q(`SELECT count(*)::int c FROM orders WHERE customer_id=$1 AND status IN ${ACTIVE}`, [req.user.id]);
  if (n.c >= 2) return bad(res, 'عندك طلبين شغالين بالفعل');
  const [o] = await q('INSERT INTO orders(customer_id,txt,zone_name,addr,price) VALUES($1,$2,$3,$4,$5) RETURNING id',
    [req.user.id, String(txt).trim().slice(0, 500), z.name, String(addr).trim().slice(0, 300), z.price]);
  await dispatch(); res.json({ id: o.id });
}));
app.post('/api/orders/:id/cancel', auth('customer'), h(async (req, res) => {
  const r = await pool.query("UPDATE orders SET status='cancelled',driver_id=NULL WHERE id=$1 AND customer_id=$2 AND status IN ('waiting','assigned')", [+req.params.id, req.user.id]);
  if (!r.rowCount) return bad(res, 'مينفعش تلغي الطلب في المرحلة دي');
  await dispatch(); res.json({ ok: 1 });
}));

/* driver */
app.get('/api/driver/me', auth('driver'), h(async (req, res) => {
  const [me] = await q('SELECT online FROM users WHERE id=$1', [req.user.id]);
  const [j] = await q(`${OSEL} WHERE o.driver_id=$1 AND o.status IN ${BUSY} LIMIT 1`, [req.user.id]);
  const [s] = await q(`SELECT count(*)::int n,coalesce(sum(price),0)::int total FROM orders WHERE driver_id=$1 AND status='done' AND done_at>=${TODAY}`, [req.user.id]);
  res.json({ online: me.online, stats: s, job: j ? { id: j.id, txt: j.txt, zone: j.zone_name, addr: j.addr, price: j.price, status: j.status,
    customer: j.status === 'assigned' ? null : { name: j.cname, phone: j.cphone } } : null });
}));
app.post('/api/driver/online', auth('driver'), h(async (req, res) => {
  const on = !!(req.body && req.body.online);
  await q('UPDATE users SET online=$1 WHERE id=$2', [on, req.user.id]);
  if (!on) await q(RELEASE, [req.user.id]);
  await dispatch(); res.json({ ok: 1 });
}));
const ACTS = {
  accept: "UPDATE orders SET status='accepted' WHERE id=$1 AND driver_id=$2 AND status='assigned'",
  reject: "UPDATE orders SET rejected=array_append(rejected,driver_id),driver_id=NULL,status='waiting' WHERE id=$1 AND driver_id=$2 AND status='assigned'",
  pick: "UPDATE orders SET status='delivering' WHERE id=$1 AND driver_id=$2 AND status='accepted'",
  done: "UPDATE orders SET status='done',done_at=now() WHERE id=$1 AND driver_id=$2 AND status='delivering'" };
app.post('/api/driver/orders/:id/:action', auth('driver'), h(async (req, res) => {
  const sql = ACTS[req.params.action];
  if (!sql) return bad(res, 'إجراء غلط', 404);
  const r = await pool.query(sql, [+req.params.id, req.user.id]);
  if (!r.rowCount) return bad(res, 'الطلب اتغيّر، حدّث الصفحة');
  await dispatch(); res.json({ ok: 1 });
}));

/* admin */
app.get('/api/admin/overview', auth('admin'), h(async (req, res) => {
  const [stats] = await q(`SELECT count(*)::int total,coalesce(sum(price) FILTER (WHERE status='done'),0)::int revenue,
    count(*) FILTER (WHERE status='waiting')::int waiting FROM orders WHERE created_at>=${TODAY}`);
  const orders = (await q(`${OSEL} ORDER BY o.id DESC LIMIT 100`)).map(o => ({ id: o.id, txt: o.txt, zone: o.zone_name, addr: o.addr,
    price: o.price, status: o.status, cname: o.cname, cphone: o.cphone, dname: o.dname, driver_id: o.driver_id }));
  const drivers = await q(`SELECT u.id,u.name,u.phone,u.online,u.active,
    EXISTS(SELECT 1 FROM orders b WHERE b.driver_id=u.id AND b.status IN ${BUSY}) busy FROM users u WHERE u.role='driver' ORDER BY u.id`);
  res.json({ stats, orders, drivers, zones: await q('SELECT id,name,price FROM zones ORDER BY id') });
}));
app.post('/api/admin/zones', auth('admin'), h(async (req, res) => {
  const { name, price } = req.body || {};
  if (!name || !(+price >= 0) || price === '' || price == null) return bad(res, 'اكتب اسم المنطقة والسعر');
  await q('INSERT INTO zones(name,price) VALUES($1,$2)', [String(name).trim().slice(0, 60), Math.round(+price)]);
  broadcast(); res.json({ ok: 1 });
}));
app.put('/api/admin/zones/:id', auth('admin'), h(async (req, res) => {
  const p = Math.round(+req.body.price);
  if (!(p >= 0)) return bad(res, 'سعر غلط');
  await q('UPDATE zones SET price=$1 WHERE id=$2', [p, +req.params.id]); broadcast(); res.json({ ok: 1 });
}));
app.delete('/api/admin/zones/:id', auth('admin'), h(async (req, res) => {
  const [c] = await q('SELECT count(*)::int c FROM zones');
  if (c.c < 2) return bad(res, 'لازم تفضل منطقة واحدة على الأقل');
  await q('DELETE FROM zones WHERE id=$1', [+req.params.id]); broadcast(); res.json({ ok: 1 });
}));
app.post('/api/admin/drivers', auth('admin'), h(async (req, res) => {
  const { name, phone, password } = req.body || {};
  if (!name || !PH.test(phone)) return bad(res, 'اكتب الاسم ورقم موبايل صحيح');
  if (!password || String(password).length < 6) return bad(res, 'كلمة السر 6 حروف على الأقل');
  const r = await q("INSERT INTO users(name,phone,pass,role) VALUES($1,$2,$3,'driver') ON CONFLICT(phone) DO NOTHING RETURNING id",
    [String(name).trim().slice(0, 60), phone, await bcrypt.hash(String(password), 10)]);
  if (!r[0]) return bad(res, 'الرقم ده مسجّل قبل كده');
  broadcast(); res.json({ ok: 1 });
}));
app.put('/api/admin/drivers/:id', auth('admin'), h(async (req, res) => {
  const id = +req.params.id, { active, password } = req.body || {};
  if (typeof active === 'boolean') {
    await q("UPDATE users SET active=$1,online=(online AND $1) WHERE id=$2 AND role='driver'", [active, id]);
    if (!active) await q(RELEASE, [id]);
  }
  if (password) {
    if (String(password).length < 6) return bad(res, 'كلمة السر 6 حروف على الأقل');
    await q("UPDATE users SET pass=$1 WHERE id=$2 AND role='driver'", [await bcrypt.hash(String(password), 10), id]);
  }
  await dispatch(); res.json({ ok: 1 });
}));
app.post('/api/admin/orders/:id/assign', auth('admin'), h(async (req, res) => {
  const r = await pool.query("UPDATE orders SET driver_id=$1,status='assigned',assigned_at=now() WHERE id=$2 AND status IN ('waiting','assigned') AND EXISTS(SELECT 1 FROM users WHERE id=$1 AND role='driver' AND active)",
    [+req.body.driver_id || 0, +req.params.id]);
  if (!r.rowCount) return bad(res, 'مينفعش تحوّل الطلب ده');
  broadcast(); res.json({ ok: 1 });
}));
app.post('/api/admin/orders/:id/cancel', auth('admin'), h(async (req, res) => {
  const r = await pool.query(`UPDATE orders SET status='cancelled',driver_id=NULL WHERE id=$1 AND status IN ${ACTIVE}`, [+req.params.id]);
  if (!r.rowCount) return bad(res, 'مينفعش تلغي الطلب ده');
  await dispatch(); res.json({ ok: 1 });
}));

app.use('/api', (req, res) => bad(res, 'مش موجود', 404));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'حصل خطأ في السيرفر' }); });

(async () => {
  await pool.query(SCHEMA);
  if (!(await q('SELECT 1 FROM zones LIMIT 1')).length) await q("INSERT INTO zones(name,price) VALUES('المنطقة الأولى',20),('المنطقة التانية',30)");
  if (ADMIN_PHONE && ADMIN_PASSWORD) {
    await q("INSERT INTO users(name,phone,pass,role) VALUES('الأدمن',$1,$2,'admin') ON CONFLICT(phone) DO UPDATE SET pass=$2,role='admin',active=true",
      [ADMIN_PHONE, await bcrypt.hash(ADMIN_PASSWORD, 10)]);
  } else console.warn('ADMIN_PHONE / ADMIN_PASSWORD not set: no admin account created');
  app.listen(PORT, () => console.log('Tawseela running on :' + PORT));
})().catch(e => { console.error(e); process.exit(1); });
